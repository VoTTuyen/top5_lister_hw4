export default function SplashScreen() {
    return (
        <div id="splash-screen">
            The Top 5<br />
            Lister
        </div>
    )
}